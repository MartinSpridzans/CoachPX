"""DuckDuckGo Search API toolkit."""

from langchain.tools.ddg_search.tool import DuckDuckGoSearchTool

__all__ = ["DuckDuckGoSearchTool"]
