class RateLimitExceeded(Exception):
    """Exception raised when the rate limit is exceeded."""

    pass
